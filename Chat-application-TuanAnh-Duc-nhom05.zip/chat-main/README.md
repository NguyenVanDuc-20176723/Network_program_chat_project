## Thuc Hanh Lap Trinh Mang
## Ung dung chat voi lap trinh socket - ngon ngu lap trinh C

# Thanh vien:
Nguyen Van Duc - 20176723<br>
Nguyen Tuan Anh - 20176692

Cap nhat 10/12/2020

# Cong cu:
- GTK 3 , glade de thiet ke UI
- socket - TCP de ket noi client voi server
- database luu du lieu nguoi dung (update sau)<br>
...(dang cap nhat)

# Chay app
- clone ve may cua ban
- cd vao thu muc chua source
- make
- server: ./server port_number<br>
	vd: ./server 1212
- client: ./application 127.0.0.1 port_number<br>
	vd: ./application 127.0.0.1 1212

---------------------------end---------------------------
