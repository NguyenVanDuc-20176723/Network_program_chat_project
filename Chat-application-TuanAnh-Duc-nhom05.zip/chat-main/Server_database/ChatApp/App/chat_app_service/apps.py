from django.apps import AppConfig


class ChatServiceConfig(AppConfig):
    name = 'chat_app_service'
