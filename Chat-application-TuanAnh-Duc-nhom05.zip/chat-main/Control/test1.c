#include<stdio.h>
#include <unistd.h>
int main()
{
   printf("Sleeping for 10 second.\n");
   sleep(10);
   printf("hello");
   return 0;
}